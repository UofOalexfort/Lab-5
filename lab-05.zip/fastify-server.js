//Below is required anytime you are using fastify.
const fastify = require("fastify")();
const fs = require("fs");
// Get route and JSON/object reply

//this needs to be at the top as its a global variable, if it was within the get route, it would not be global as each get route is a code block, isolating variables within it from the rest of the document
const students = [
  {
    id: 1,
    last: "Last1",
    first: "First1",
  },
  {
    id: 2,
    last: "Last2",
    first: "First2",
  },
  {
    id: 3,
    last: "Last3",
    first: "First3",
  },
];
//below is a get route, always needed when writing a web server code.
//it is alwasy written like it is below, with fastify.get, then the / (aka the route). a name can be given to the route like /students
fastify.get("/cit", (request, reply) => {
  //below is the reply statement, and is always needed when using a get route
  //the code is correlated to a certain outcome (aka 404 = error), but the message associated with a code is not built in, you need to wirte the message associated with it.
  //reply statements always have a .code, .header, and .send.
  //.send is where html will be sent to the webserver
  //*careful with brackets and parentheses as there are alot of them that span differnet lines within these code blocks
  reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8")
    .send({ test: "This is a test" });
});

//students route - all students
fastify.get("/cit/student", (request, reply) => {
  reply
    .code(200)
    .header("Content-Type", "application/json; charset=utf-8") //tells the .send how to display what is in .send (.header will always start with content-type, follwoed by the MIME type, which tells .send how to display the info within .send)(text/html will retrun text on the webpage)(apploication/json will write to the package.json file)
    .send(students);
});

//student/:id route   -return specific id 
fastify.get("/cit/student/:id", (request, reply) => {
  const { id } = request.params;
  let student = null;
  for (const item of students) {
    if (item.id === parseInt(id)) {
      student = item;
      break;
    }
  }

  if (!student) {
    reply
      .code(404)
      .header("Content-Type", "text/html; charset=utf-8") //tells the .send how to display what is in .send (.header will always start with content-type, follwoed by the MIME type, which tells .send how to display the info within .send)(text/html will retrun text on the webpage)(apploication/json will write to the package.json file)
      .send("Not found");
  } else {
    if (student) {
      reply
        .code(200)
        .header("Content-Type", "application/json; charset=utf-8") //tells the .send how to display what is in .send (.header will always start with content-type, follwoed by the MIME type, which tells .send how to display the info within .send)(text/html will retrun text on the webpage)(apploication/json will write to the package.json file)
        .send(student);
    }
  }
});


//unmatched 
fastify.get("*", (request, reply) => {
  reply
    .code(404)
    .header("Content-Type", "application/json; charset=utf-8") //tells the .send how to display what is in .send (.header will always start with content-type, follwoed by the MIME type, which tells .send how to display the info within .send)(text/html will retrun text on the webpage)(apploication/json will write to the package.json file)
    .send({ test: "this is an error" });
});


//post route
fastify.post("/cit/student", (request, reply) => {

const { last , first } = request.body;
const id = null;

if(!last || !first){      //if not this or (||) that, then reply blank, only one condtion has to be true when using or 
  reply
  .code(404)
  .header("Content-Type", "text/html; charset=utf-8") //tells the .send how to display what is in .send (.header will always start with content-type, follwoed by the MIME type, which tells .send how to display the info within .send)(text/html will retrun text on the webpage)(apploication/json will write to the package.json file)
  .send("Not found");

} else {          
  let id = 0; 
  for(const student of students){
    if(student.id > id){
      id = student.id;
    }
  }

id++;
students.push({id, last, first});      //adds new student value to array

reply
  .code(200)
  .header("Content-Type", "application/json; charset=utf-8") //tells the .send how to display what is in .send (.header will always start with content-type, follwoed by the MIME type, which tells .send how to display the info within .send)(text/html will retrun text on the webpage)(apploication/json will write to the package.json file)
  .send(students[students.length-1]);
}

let response = request.body;

reply
  .code(200)
  .header("Content-Type", "application/json; charset=utf-8") //tells the .send how to display what is in .send (.header will always start with content-type, follwoed by the MIME type, which tells .send how to display the info within .send)(text/html will retrun text on the webpage)(apploication/json will write to the package.json file)
  .send(response);
});


// Start server and listen to requests using Fastify
//all webservers need the following code to start and allow us to connect to them
const listenIP = "localhost";
const listenPort = 8082;
fastify.listen(listenPort, listenIP, (err, address) => {
  if (err) {
    console.log(err);
    process.exit(1);
  }
  console.log(`Server listening on ${address}`);        //sends adress to the console (can click it)
});
